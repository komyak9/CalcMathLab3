﻿namespace Lab_3
{
    enum BreakPointType
    {
        RepairableGap,
        Jump,
        Infinity,
        SignificantSingularPoints,
        NoGap
    }
}
